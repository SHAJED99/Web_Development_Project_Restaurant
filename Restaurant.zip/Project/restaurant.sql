-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2021 at 03:03 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `carousel_slider`
--

CREATE TABLE `carousel_slider` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `sub_title` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carousel_slider`
--

INSERT INTO `carousel_slider` (`id`, `title`, `sub_title`, `image`) VALUES
(1, 'Title1', 'Shajedur Rahman Panna', './assets/image/banner/1.png'),
(2, 'Title2', 'Shajedur Rahman Panna Shajedur Rahman Panna Shajedur Rahman Panna Shajedur Rahman Panna Shajedur Rahman Panna Shajedur Rahman Panna Shajedur Rahman Panna ', './assets/image/banner/2.png'),
(3, 'Title3', 'large image taking so much time to load from mysql3', './assets/image/banner/3.png'),
(4, 'Hey 4', 'large image taking so much time to load from mysql4', './assets/image/banner/4.png');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `mobile_number` varchar(11) NOT NULL,
  `first_name` text DEFAULT NULL,
  `last_name` text DEFAULT NULL,
  `email` text NOT NULL,
  `last_order` int(11) DEFAULT NULL,
  `cart` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`mobile_number`, `first_name`, `last_name`, `email`, `last_order`, `cart`) VALUES
('01703718801', 'shajedur rahman', 'shajed99', 'shajedurrahmanpanna.panna@gmail.com', NULL, 'a:5:{i:3;s:2:\"16\";i:4;s:2:\"15\";i:5;s:2:\"17\";i:6;s:2:\"18\";i:9;s:2:\"23\";}'),
('01703718809', 'shajedur rahman', 'panna', 'shajedurrahmanpanna.panna@gmail.com', NULL, 'a:3:{i:14;s:2:\"27\";i:15;s:2:\"28\";i:16;s:2:\"29\";}'),
('01703718899', 'shajedur rahman', 'panna', 'shajedurrahmanpanna.panna@gmail.com', NULL, 'a:4:{i:0;s:1:\"4\";i:1;s:1:\"9\";i:2;s:2:\"29\";i:3;s:2:\"16\";}');

-- --------------------------------------------------------

--
-- Table structure for table `customer_loginform`
--

CREATE TABLE `customer_loginform` (
  `mobile_number` varchar(11) NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_loginform`
--

INSERT INTO `customer_loginform` (`mobile_number`, `password`) VALUES
('01703718801', '78ec0a3a589aa17bcff9700b8e09864c'),
('01703718809', '3092003ada239e1cbb4a43f06ee04d12'),
('01703718899', '78ec0a3a589aa17bcff9700b8e09864c');

-- --------------------------------------------------------

--
-- Table structure for table `food_list_post`
--

CREATE TABLE `food_list_post` (
  `food_id` int(11) NOT NULL,
  `food_name` text NOT NULL,
  `food_details` text NOT NULL,
  `price` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `type` text NOT NULL,
  `image_location` text NOT NULL,
  `food_rating` double NOT NULL DEFAULT 5
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `food_list_post`
--

INSERT INTO `food_list_post` (`food_id`, `food_name`, `food_details`, `price`, `status`, `type`, `image_location`, `food_rating`) VALUES
(1, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.', 221, 0, 'fast_food', 'assets/image/food_image/1.png', 4.9),
(2, 'Noodles', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 120, 0, 'platter', 'assets/image/food_image/2.png', 3.7),
(3, 'Noodles', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 120, 0, 'platter', 'assets/image/food_image/3.png', 1.6),
(4, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.', 221, 26, 'fast_food', 'assets/image/food_image/2.png', 4.5),
(8, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 200, 0, 'fast_food', 'assets/image/food_image/6.png', 5),
(9, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 200, 30, 'fast_food', 'assets/image/food_image/1.png', 5),
(12, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.', 221, 28, 'fast_food', 'assets/image/food_image/1.png', 2.6),
(13, 'Noodles', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 120, 0, 'platter', 'assets/image/food_image/2.png', 3.7),
(14, 'Noodles', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 120, 0, 'platter', 'assets/image/food_image/3.png', 1.6),
(15, 'Pizza', 'hi', 221, 60, 'fast_food', 'assets/image/food_image/2.png', 4.5),
(16, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 200, 71, 'fast_food', 'assets/image/food_image/6.png', 5),
(17, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 200, 47, 'fast_food', 'assets/image/food_image/1.png', 5),
(18, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.', 221, 70, 'fast_food', 'assets/image/food_image/1.png', 2.6),
(19, 'Noodles', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 120, 0, 'platter', 'assets/image/food_image/2.png', 3.7),
(20, 'Noodles', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 120, 0, 'platter', 'assets/image/food_image/3.png', 1.6),
(21, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.', 221, 70, 'fast_food', 'assets/image/food_image/2.png', 4.5),
(22, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 200, 69, 'fast_food', 'assets/image/food_image/6.png', 5),
(23, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 200, 59, 'fast_food', 'assets/image/food_image/1.png', 5),
(24, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.', 221, 47, 'fast_food', 'assets/image/food_image/1.png', 2.6),
(25, 'Noodles', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 120, 0, 'platter', 'assets/image/food_image/2.png', 3.7),
(26, 'Noodles', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 120, 0, 'platter', 'assets/image/food_image/3.png', 1.6),
(27, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.Some quick example text to build on the card title and make up the bulk of the card\'s content.', 221, 67, 'fast_food', 'assets/image/food_image/2.png', 4.5),
(28, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 200, 66, 'fast_food', 'assets/image/food_image/6.png', 5),
(29, 'Pizza', 'Some quick example text to build on the card title and make up the bulk of the card\'s content.', 200, 65, 'fast_food', 'assets/image/food_image/1.png', 5);

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `order_id` int(11) NOT NULL,
  `order_status` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total_cost` int(11) NOT NULL,
  `order_owner_number` varchar(11) NOT NULL,
  `items` text NOT NULL,
  `items_amount` text NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`order_id`, `order_status`, `time`, `total_cost`, `order_owner_number`, `items`, `items_amount`, `address`) VALUES
(1, -1, '2021-06-12 08:41:12', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 9'),
(2, 0, '2021-06-12 08:42:08', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 10'),
(3, -1, '2021-06-12 08:41:12', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 9'),
(4, 0, '2021-06-12 08:42:08', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 10'),
(5, 0, '2021-06-12 08:46:53', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 7'),
(6, 0, '2021-06-12 09:10:41', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 8'),
(7, 0, '2021-06-13 08:26:43', 31470, '01703718809', 'a:15:{i:0;s:1:\"4\";i:1;s:2:\"29\";i:2;s:2:\"28\";i:3;s:2:\"27\";i:4;s:1:\"8\";i:5;s:1:\"9\";i:6;s:2:\"12\";i:7;s:2:\"15\";i:8;s:2:\"16\";i:9;s:2:\"17\";i:10;s:2:\"18\";i:11;s:2:\"24\";i:12;s:2:\"23\";i:13;s:2:\"22\";i:14;s:2:\"21\";}', 'a:15:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";i:4;s:2:\"10\";i:5;s:2:\"10\";i:6;s:2:\"10\";i:7;s:2:\"10\";i:8;s:2:\"10\";i:9;s:2:\"10\";i:10;s:2:\"10\";i:11;s:2:\"10\";i:12;s:2:\"10\";i:13;s:2:\"10\";i:14;s:2:\"10\";}', 'in 6'),
(8, 0, '2021-06-19 06:20:04', 8420, '01703718809', 'a:4:{i:0;s:1:\"8\";i:1;s:1:\"4\";i:2;s:2:\"12\";i:3;s:1:\"9\";}', 'a:4:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";}', 'in 10'),
(9, 0, '2021-06-21 08:25:10', 2642, '01703718801', 'a:5:{i:0;s:2:\"16\";i:1;s:2:\"15\";i:2;s:2:\"17\";i:3;s:2:\"18\";i:4;s:2:\"23\";}', 'a:5:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"9\";}', 'in 8'),
(10, 0, '2021-06-19 06:29:11', 12630, '01703718809', 'a:6:{i:0;s:1:\"8\";i:1;s:1:\"4\";i:2;s:2:\"12\";i:3;s:1:\"9\";i:4;s:2:\"17\";i:5;s:2:\"24\";}', 'a:6:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";i:4;s:2:\"10\";i:5;s:2:\"10\";}', 'in 10'),
(11, 0, '2021-06-19 06:20:04', 8420, '01703718809', 'a:4:{i:0;s:1:\"8\";i:1;s:1:\"4\";i:2;s:2:\"12\";i:3;s:1:\"9\";}', 'a:4:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";}', 'in 10'),
(12, 0, '2021-06-13 08:26:43', 31470, '01703718809', 'a:15:{i:0;s:1:\"4\";i:1;s:2:\"29\";i:2;s:2:\"28\";i:3;s:2:\"27\";i:4;s:1:\"8\";i:5;s:1:\"9\";i:6;s:2:\"12\";i:7;s:2:\"15\";i:8;s:2:\"16\";i:9;s:2:\"17\";i:10;s:2:\"18\";i:11;s:2:\"24\";i:12;s:2:\"23\";i:13;s:2:\"22\";i:14;s:2:\"21\";}', 'a:15:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";i:4;s:2:\"10\";i:5;s:2:\"10\";i:6;s:2:\"10\";i:7;s:2:\"10\";i:8;s:2:\"10\";i:9;s:2:\"10\";i:10;s:2:\"10\";i:11;s:2:\"10\";i:12;s:2:\"10\";i:13;s:2:\"10\";i:14;s:2:\"10\";}', 'in 6'),
(13, 0, '2021-06-12 09:10:41', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 8'),
(14, 0, '2021-06-12 08:46:53', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 7'),
(15, 0, '2021-06-12 08:42:08', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 10'),
(16, -1, '2021-06-12 08:41:12', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 9'),
(17, 0, '2021-06-12 08:42:08', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 10'),
(18, -1, '2021-06-12 08:41:12', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 9'),
(19, -1, '2021-06-12 08:41:12', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 9'),
(20, -1, '2021-06-12 08:41:12', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 9'),
(21, -1, '2021-06-12 08:41:12', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 9'),
(22, -1, '2021-06-12 08:41:12', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 9'),
(23, 0, '2021-06-12 08:42:08', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 10'),
(24, 0, '2021-06-12 08:42:08', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 10'),
(25, 0, '2021-06-12 08:46:53', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 7'),
(26, 0, '2021-06-12 09:10:41', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 8'),
(27, 0, '2021-06-13 08:26:43', 31470, '01703718809', 'a:15:{i:0;s:1:\"4\";i:1;s:2:\"29\";i:2;s:2:\"28\";i:3;s:2:\"27\";i:4;s:1:\"8\";i:5;s:1:\"9\";i:6;s:2:\"12\";i:7;s:2:\"15\";i:8;s:2:\"16\";i:9;s:2:\"17\";i:10;s:2:\"18\";i:11;s:2:\"24\";i:12;s:2:\"23\";i:13;s:2:\"22\";i:14;s:2:\"21\";}', 'a:15:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";i:4;s:2:\"10\";i:5;s:2:\"10\";i:6;s:2:\"10\";i:7;s:2:\"10\";i:8;s:2:\"10\";i:9;s:2:\"10\";i:10;s:2:\"10\";i:11;s:2:\"10\";i:12;s:2:\"10\";i:13;s:2:\"10\";i:14;s:2:\"10\";}', 'in 6'),
(28, 0, '2021-06-19 06:20:04', 8420, '01703718809', 'a:4:{i:0;s:1:\"8\";i:1;s:1:\"4\";i:2;s:2:\"12\";i:3;s:1:\"9\";}', 'a:4:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";}', 'in 10'),
(29, 0, '2021-06-19 06:20:04', 8420, '01703718809', 'a:4:{i:0;s:1:\"8\";i:1;s:1:\"4\";i:2;s:2:\"12\";i:3;s:1:\"9\";}', 'a:4:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";}', 'in 10'),
(30, 0, '2021-06-13 08:26:43', 31470, '01703718809', 'a:15:{i:0;s:1:\"4\";i:1;s:2:\"29\";i:2;s:2:\"28\";i:3;s:2:\"27\";i:4;s:1:\"8\";i:5;s:1:\"9\";i:6;s:2:\"12\";i:7;s:2:\"15\";i:8;s:2:\"16\";i:9;s:2:\"17\";i:10;s:2:\"18\";i:11;s:2:\"24\";i:12;s:2:\"23\";i:13;s:2:\"22\";i:14;s:2:\"21\";}', 'a:15:{i:0;s:2:\"10\";i:1;s:2:\"10\";i:2;s:2:\"10\";i:3;s:2:\"10\";i:4;s:2:\"10\";i:5;s:2:\"10\";i:6;s:2:\"10\";i:7;s:2:\"10\";i:8;s:2:\"10\";i:9;s:2:\"10\";i:10;s:2:\"10\";i:11;s:2:\"10\";i:12;s:2:\"10\";i:13;s:2:\"10\";i:14;s:2:\"10\";}', 'in 6'),
(31, 0, '2021-06-12 09:10:41', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 8'),
(32, 0, '2021-06-12 08:46:53', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 7'),
(33, 0, '2021-06-12 08:42:08', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 10'),
(34, 0, '2021-06-12 08:42:08', 842, '01703718809', 'a:4:{i:0;s:1:\"4\";i:1;s:2:\"12\";i:2;s:1:\"9\";i:3;s:1:\"8\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";}', 'in 10'),
(35, 0, '2021-06-19 06:53:03', 2000, '01703718809', 'a:1:{i:0;s:1:\"8\";}', 'a:1:{i:0;s:2:\"10\";}', 'in 10'),
(36, 0, '2021-06-19 06:56:19', 800, '01703718809', 'a:1:{i:0;s:1:\"8\";}', 'a:1:{i:0;s:1:\"4\";}', 'in 10'),
(37, 0, '2021-06-19 06:57:05', 200, '01703718809', 'a:1:{i:0;s:1:\"8\";}', 'a:1:{i:0;s:1:\"1\";}', 'in 5'),
(38, 0, '2021-06-20 20:07:09', 221, '01703718809', 'a:1:{i:0;s:1:\"4\";}', 'a:1:{i:0;s:1:\"1\";}', 'in 7'),
(39, 0, '2021-06-20 21:01:35', 1063, '01703718809', 'a:5:{i:0;s:1:\"9\";i:1;s:2:\"17\";i:2;s:2:\"24\";i:3;s:2:\"15\";i:4;s:2:\"12\";}', 'a:5:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";}', 'in 7'),
(40, 0, '2021-06-20 21:02:30', 1063, '01703718809', 'a:5:{i:0;s:1:\"9\";i:1;s:2:\"17\";i:2;s:2:\"24\";i:3;s:2:\"15\";i:4;s:2:\"12\";}', 'a:5:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";}', 'in 10'),
(41, 0, '2021-06-20 21:29:44', 4757, '01703718809', 'a:5:{i:0;s:1:\"9\";i:1;s:2:\"17\";i:2;s:2:\"24\";i:3;s:2:\"15\";i:4;s:2:\"12\";}', 'a:5:{i:0;s:1:\"1\";i:1;s:1:\"4\";i:2;s:1:\"6\";i:3;s:1:\"1\";i:4;s:2:\"10\";}', 'in 9'),
(42, 0, '2021-06-21 08:25:05', 2589, '01703718809', 'a:4:{i:0;s:1:\"9\";i:1;s:2:\"17\";i:2;s:2:\"15\";i:3;s:2:\"12\";}', 'a:4:{i:0;s:1:\"1\";i:1;s:1:\"2\";i:2;s:1:\"4\";i:3;s:1:\"5\";}', 'in 6'),
(43, 0, '2021-06-21 08:25:08', 621, '01703718899', 'a:2:{i:0;s:1:\"4\";i:1;s:1:\"9\";}', 'a:2:{i:0;s:1:\"1\";i:1;s:1:\"2\";}', 'in 7'),
(44, 0, '2021-06-21 10:53:46', 18535, '01703718809', 'a:14:{i:0;s:1:\"9\";i:1;s:2:\"17\";i:2;s:2:\"24\";i:3;s:2:\"15\";i:4;s:2:\"12\";i:5;s:1:\"4\";i:6;s:2:\"16\";i:7;s:2:\"18\";i:8;s:2:\"21\";i:9;s:2:\"22\";i:10;s:2:\"23\";i:11;s:2:\"27\";i:12;s:2:\"28\";i:13;s:2:\"29\";}', 'a:14:{i:0;s:2:\"10\";i:1;s:1:\"9\";i:2;s:1:\"8\";i:3;s:1:\"7\";i:4;s:1:\"1\";i:5;s:1:\"2\";i:6;s:1:\"3\";i:7;s:1:\"4\";i:8;s:1:\"5\";i:9;s:1:\"6\";i:10;s:1:\"7\";i:11;s:1:\"8\";i:12;s:1:\"9\";i:13;s:2:\"10\";}', 'in 5'),
(45, -1, '2021-06-21 11:52:41', 2947, '01703718809', 'a:14:{i:0;s:1:\"9\";i:1;s:2:\"17\";i:2;s:2:\"24\";i:3;s:2:\"15\";i:4;s:2:\"12\";i:5;s:1:\"4\";i:6;s:2:\"16\";i:7;s:2:\"18\";i:8;s:2:\"21\";i:9;s:2:\"22\";i:10;s:2:\"23\";i:11;s:2:\"27\";i:12;s:2:\"28\";i:13;s:2:\"29\";}', 'a:14:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";}', 'in 8'),
(46, 0, '2021-06-21 19:17:30', 2947, '01703718809', 'a:14:{i:0;s:1:\"9\";i:1;s:2:\"17\";i:2;s:2:\"24\";i:3;s:2:\"15\";i:4;s:2:\"12\";i:5;s:1:\"4\";i:6;s:2:\"16\";i:7;s:2:\"18\";i:8;s:2:\"21\";i:9;s:2:\"22\";i:10;s:2:\"23\";i:11;s:2:\"27\";i:12;s:2:\"28\";i:13;s:2:\"29\";}', 'a:14:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";}', 'in 10'),
(47, 1, '2021-06-23 08:45:56', 2947, '01703718809', 'a:14:{i:0;s:1:\"9\";i:1;s:2:\"17\";i:2;s:2:\"24\";i:3;s:2:\"15\";i:4;s:2:\"12\";i:5;s:1:\"4\";i:6;s:2:\"16\";i:7;s:2:\"18\";i:8;s:2:\"21\";i:9;s:2:\"22\";i:10;s:2:\"23\";i:11;s:2:\"27\";i:12;s:2:\"28\";i:13;s:2:\"29\";}', 'a:14:{i:0;s:1:\"1\";i:1;s:1:\"1\";i:2;s:1:\"1\";i:3;s:1:\"1\";i:4;s:1:\"1\";i:5;s:1:\"1\";i:6;s:1:\"1\";i:7;s:1:\"1\";i:8;s:1:\"1\";i:9;s:1:\"1\";i:10;s:1:\"1\";i:11;s:1:\"1\";i:12;s:1:\"1\";i:13;s:1:\"1\";}', 'in 8');

-- --------------------------------------------------------

--
-- Table structure for table `shop_other_variable`
--

CREATE TABLE `shop_other_variable` (
  `id` int(1) NOT NULL DEFAULT current_timestamp(),
  `total_seat_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shop_other_variable`
--

INSERT INTO `shop_other_variable` (`id`, `total_seat_number`) VALUES
(2147483647, 10);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carousel_slider`
--
ALTER TABLE `carousel_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD UNIQUE KEY `mobile_number` (`mobile_number`),
  ADD KEY `last_order` (`last_order`);

--
-- Indexes for table `customer_loginform`
--
ALTER TABLE `customer_loginform`
  ADD UNIQUE KEY `mobile_number` (`mobile_number`);

--
-- Indexes for table `food_list_post`
--
ALTER TABLE `food_list_post`
  ADD UNIQUE KEY `food_id` (`food_id`);

--
-- Indexes for table `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `order_owner_number` (`order_owner_number`);

--
-- Indexes for table `shop_other_variable`
--
ALTER TABLE `shop_other_variable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carousel_slider`
--
ALTER TABLE `carousel_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `food_list_post`
--
ALTER TABLE `food_list_post`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `order_list`
--
ALTER TABLE `order_list`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`mobile_number`) REFERENCES `customer_loginform` (`mobile_number`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `order_list`
--
ALTER TABLE `order_list`
  ADD CONSTRAINT `order_list_ibfk_1` FOREIGN KEY (`order_owner_number`) REFERENCES `customer_loginform` (`mobile_number`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
