<?php

class Messages{
	public static function setMsg($text, $type="success") {
		if($type == 'error') {
			$_SESSION['errorMsg'] = $text;
		} else {
			$_SESSION['successMsg'] = $text;
		}
	}

	public static function display() {
		if(isset($_SESSION['errorMsg'])) {
			?>
			<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="myModal">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="alert alert-danger"><?php echo $_SESSION['errorMsg']; ?></div>
					</div>
				</div>
			</div>

			<!-- <script> $('#myModal').modal('show');</script> -->
			<?php
			unset($_SESSION['errorMsg']);
		}

		if(isset($_SESSION['successMsg'])) {
			?>
			<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="myModal">
				<div class="modal-dialog modal-lg">
					<div class="modal-content">
						<div class="alert alert-success"><?php echo $_SESSION['successMsg']; ?></div>
					</div>
				</div>
			</div>

			<!-- <script> $('#myModal').modal('show');</script> -->
			<?php
			unset($_SESSION['successMsg']);
		}
	}

	public static function error_404() {
		$view = 'views/web_page_not_found/404_error.php';
		require('views/main.php');
	}
}