<?php 

//Define DP var
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "restaurant");

//Define URL
define("ROOT_PATH", "/restaurant/");
define("ROOT_URL", "http://".$_SERVER['HTTP_HOST']."/restaurant/");

//Define Other Valus
define("CURRENCY", "tk");
define("COMPANY_NAME", "Restaurant");