<?php 
class Foods extends Controller{
    protected function details(){
        $viewmodel = new FoodModel();

        $food_detail = $viewmodel->details($this->id);

        if($food_detail) {
            $this->returnView($food_detail, true);
        } else {
            Messages::error_404();
        }
    }
}