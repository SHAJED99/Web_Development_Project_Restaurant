<?php 
class Users extends Controller{
    protected function login(){
        if(!isset($_SESSION['is_logged_in'])){
            $viewmodel = new UserModel();
            $this->returnView($viewmodel->login(), true);
        } else {
            header('Location: '.ROOT_URL);
        }
    }

    protected function details(){
        if(isset($_SESSION['is_logged_in'])){
            $viewmodel = new UserModel();
            $this->returnView($viewmodel->details(), true);
        } else {
            header('Location: '.ROOT_URL.'users/login#login');
        }
    }

    protected function logout(){
        if(isset($_SESSION['is_logged_in'])){
            session_destroy();
            //Redirect
            header('Location: '.ROOT_URL);
        } else {
            header('Location: '.ROOT_URL);
        }
    }

    protected function cart() {
        if(isset($_SESSION['is_logged_in'])){
            $viewmodel = new UserModel();
            $this->returnView($viewmodel->cart(), true);
        } else {
            header('Location: '.ROOT_URL.'users/login#login');
        }
    }

    protected function order() {
        if(isset($_SESSION['is_logged_in'])){
            $viewmodel = new UserModel();
            $this->returnView($viewmodel->order(), true);
        } else {
            header('Location: '.ROOT_URL.'users/login#login');
        }
    }

    protected function orderid(){
        if(isset($_SESSION['is_logged_in'])){
            $viewmodel = new UserModel();
            $temp = $viewmodel->orderid($this->id);
            if($temp != false){
                $this->returnView($temp, true);
            } else {
                Messages::error_404();
            }
            
        } else {
            header('Location: '.ROOT_URL.'users/login#login');
        }
    }
}