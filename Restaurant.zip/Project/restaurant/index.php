<?php
//Session start
session_start();

//Include Config
require('config.php');

require('classes/Bootstrap.php');
require('classes/Controller.php');
require('classes/Model.php');
require('classes/Messages.php');
require('classes/Calculation.php');


require('controllers/home.php');
require('controllers/foods.php');
require('controllers/users.php');

require('models/home.php');
require('models/food.php');
require('models/user.php');

require('required/php/update_session_status.php');

$bootstrap = new Bootstrap($_GET);

// print_r($_GET);

$controller = $bootstrap->createController();

if($controller){
    $controller->executeAction();
}