<?php 

//Include Config
require('config.php');

require('classes/Model.php');
require('classes/Calculation.php');

require('required/php/update_session_status.php');
session_start();

class jQuery extends Model
{
    protected function valid_user() {
        if(isset($_SESSION['user_id']) && isset($_SESSION['user_name']) && $_SESSION['user_id'] != '' && $_SESSION['user_name']['first_name'] != '' && $_SESSION['user_name']['last_name'] != '' && $_SESSION['user_name']['email'] != '') {
            $this->query('SELECT * FROM customer WHERE mobile_number = :mobile_number AND first_name = :first_name AND last_name = :last_name AND email = :email');
            $this->bind(':mobile_number', $_SESSION['user_id']);
            $this->bind(':first_name', $_SESSION['user_name']['first_name']);
            $this->bind(':last_name', $_SESSION['user_name']['last_name']);
            $this->bind(':email', $_SESSION['user_name']['email']);
            $temo_res = $this->resultSet();
            if(sizeof($temo_res) == 1) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    protected function check_available_food($check_available_food_food_id, $check_available_food_quantity) {
        $check_available_food_quantity = intval($check_available_food_quantity);
        if($check_available_food_quantity > 10 || $check_available_food_quantity < 1) {
            return false;
        } else {
            $this->query('SELECT status, price FROM food_list_post WHERE food_id = :food_id');
            $this->bind(':food_id', $check_available_food_food_id);
            $res = $this->resultSet();
            
            if(intval($res[0]['status']) >= $check_available_food_quantity){
                return array($check_available_food_quantity * intval($res[0]['price']), intval($res[0]['status']));
            } else {
                return false;
            }
        }
    }

    // protected function sub_total_cost($sub_total_cost_food_id, $sub_total_cost_food_quantity) {
    //     $this->query('SELECT price FROM food_list_post WHERE food_id = :food_id');
    // }

    // cart_add
    public function cart_add($data){
        $this->query('SELECT cart FROM customer WHERE mobile_number = :mobile_number');
        $this->bind(':mobile_number', $_SESSION['user_id']);
        $temo_cart = $this->resultSet();
        $temo_cart = array_management::creatArray($temo_cart[0]['cart']);
        
        if(!is_array($temo_cart)){
            $temo_cart = array();
        }

        if(!in_array($data['food_id'], $temo_cart)) {
            array_push($temo_cart, $data['food_id']);

            $this->query('UPDATE customer SET cart=:cart WHERE mobile_number=:mobile_number');
            $this->bind(':cart', array_management::serializeArray($temo_cart));
            $this->bind(':mobile_number', $_SESSION['user_id']);
            $this->execute();
            return 1;
        } else {
            return 0;
        }
    }

    // cart_del
    public function cart_del($data){
        $this->query('SELECT cart FROM customer WHERE mobile_number = :mobile_number');
        $this->bind(':mobile_number', $_SESSION['user_id']);
        $temo_cart = $this->resultSet();
        $temo_cart = array_management::creatArray($temo_cart[0]['cart']);
        
        if(!is_array($temo_cart)){
            $temo_cart = array();
        }

        if(in_array($data['food_id'], $temo_cart)) {
            // echo $data['food_id'];
            if (($key = array_search($data['food_id'], $temo_cart)) !== false) {
                unset($temo_cart[$key]);
            }
            // print_r($temo_cart);

            $this->query('UPDATE customer SET cart=:cart WHERE mobile_number=:mobile_number');
            $this->bind(':cart', array_management::serializeArray($temo_cart));
            $this->bind(':mobile_number', $_SESSION['user_id']);
            $this->execute();
            return 1;
        } else {
            return 0;
        }
    }

    // protected function check_previous_payment()

    public function check_out($data){
        // $view = 'views/payment/checkout.php';
        // require('views/main.php');

        
        $food_array = explode(",", $data['food_list']);
        $quantity_array = explode(",", $data['food_quantity']);
        $array_size = sizeof($food_array);  
        $order_items = [];
        $order_quentity = [];
        $total_cost = 0;
        $prev_status = [];

        if($this->valid_user()) {
            $prev_active_order = check_active_order($this);
            if($prev_active_order == false) {
                for ($i=0; $i < $array_size; $i++) { 
                    // Check If food available
                    $val = $this->check_available_food($food_array[$i], $quantity_array[$i]);
                    if(is_array($val) && $val[0]){
                        array_push($order_items, $food_array[$i]);
                        array_push($order_quentity, $quantity_array[$i]);
                        $total_cost = $total_cost + $val[0];
                        array_push($prev_status, $val[1]);
                    } else {
                        return 'There is not available food. Please refresh this page.';
                    }
                }

                // return $prev_status;
    
                // Creating order Table
                $this->query('INSERT INTO order_list (order_owner_number, order_status, items, items_amount, total_cost, address) VALUES(:order_owner_number, :order_status, :items, :items_amount, :total_cost, :address)');
                $this->bind(':order_owner_number', $_SESSION['user_id']);
                $this->bind(':order_status', "1");
                $this->bind(':items', array_management::serializeArray($order_items));
                $this->bind(':items_amount', array_management::serializeArray($order_quentity));
                $this->bind(':total_cost', $total_cost);
                $this->bind(':address', $data['order_place']);
                $this->execute();

                for ($i=0; $i < $array_size; $i++) { 
                    $this->query('UPDATE food_list_post SET status = :status WHERE food_id = :food_id');
                    $this->bind(':status', ($prev_status[$i] - $quantity_array[$i]));
                    $this->bind(':food_id', $food_array[$i]);
                    $this->execute();
                }
                return 'true';
            } else {
                return $prev_active_order;
            }
            
        } else {
            return 'Invalid user information. Please give your information to place an order.<br><a class="text-primary" href="'.ROOT_URL.'/users/details">Edit your information here.</a>';
        }
    }


    public function order_cat($status) {
        if($status == "1") {
            $this->query('SELECT order_id, order_status, DATE_FORMAT(time, "%d/%m/%Y"), total_cost FROM order_list WHERE order_owner_number = :order_owner_number AND (order_status = :order_status1 OR order_status = :order_status2 OR order_status = :order_status3 OR order_status = :order_status4) ORDER BY order_status DESC, time DESC, order_id DESC');
            $this->bind(':order_owner_number', $_SESSION['user_id']);
            $this->bind(':order_status1', "1");
            $this->bind(':order_status2', "2");
            $this->bind(':order_status3', "3");
            $this->bind(':order_status4', "4");
            $row = $this->resultSet();
            return $row;
        } elseif($status == "0") {
            $this->query('SELECT order_id, order_status, DATE_FORMAT(time, "%d/%m/%Y"), total_cost FROM order_list WHERE order_owner_number = :order_owner_number AND order_status = :order_status ORDER BY time DESC, order_id DESC');
            $this->bind(':order_owner_number', $_SESSION['user_id']);
            $this->bind(':order_status', "0");
            $row = $this->resultSet();
            return $row;
        } elseif($status == "-1") {
            $this->query('SELECT order_id, order_status, DATE_FORMAT(time, "%d/%m/%Y"), total_cost FROM order_list WHERE order_owner_number = :order_owner_number AND order_status = :order_status ORDER BY time DESC, order_id DESC');
            $this->bind(':order_owner_number', $_SESSION['user_id']);
            $this->bind(':order_status', "-1");
            $row = $this->resultSet();
            return $row;
        }
    }
}


if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(isset($_SESSION['is_logged_in']) && $_SESSION['is_logged_in']){
        $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
        if($post['jq_status'] == "cart_add") {
            // cart_add
            $temp_class = new jQuery();
            echo $temp_class->cart_add($post);
        } elseif ($post['jq_status'] == "cart_del") {
            // cart_del
            $temp_class = new jQuery();
            echo $temp_class->cart_del($post);
        } elseif ($post['jq_status'] == 'check_out') {
            // check_out
            $temp_class = new jQuery();
            echo json_encode($temp_class->check_out($post));
            // print_r($post);
        } elseif ($post['jq_status'] == 'order_cat') {
            // order_cat
            $temp_class = new jQuery();
            echo json_encode($temp_class->order_cat($post['com']));
        }
    } else {
        return -1;
    }
}