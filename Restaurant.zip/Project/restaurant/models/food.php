<?php 
class FoodModel extends Model{
    public function details($id){
        if($id != null) {
            $this->query('SELECT * FROM food_list_post WHERE food_id = :food_id');
            $this->bind(':food_id', $id);
            $rows = $this->resultset();
            if(sizeof($rows)) {
                $this->query('SELECT food_id, food_name, price, image_location, food_rating FROM food_list_post WHERE type = :type AND food_id != :food_id AND status > 0');
                $this->bind(':type', $rows[0]['type']);
                $this->bind(':food_id', $id);
                $rows2 = $this->resultset();
                $full_result = array($rows, $rows2);
                // print_r($full_result);
                update_status($this);
                return $full_result;
            } else {
                return;
            }
            
        } else {
            return;
        }
    }
}