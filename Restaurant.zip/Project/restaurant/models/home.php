<?php 
class HomeModel extends Model{
    public function Index(){
        $this->query('SELECT * FROM carousel_slider');
        $row1 = $this->resultset();

        $this->query('SELECT * FROM food_list_post');
        $row2 = $this->resultset();

        $rows = array($row1, $row2);

        // echo sizeof($rows[1]);

        update_status($this);
        return $rows;
    }
}