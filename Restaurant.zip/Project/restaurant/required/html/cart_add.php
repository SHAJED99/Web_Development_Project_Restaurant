<?php if(isset($_SESSION['is_logged_in'])) { ?>
    <script>
        $("form").submit(function(){
            var submit_button = $(this).find("[type=submit]");

            if(!submit_button.hasClass('disabled')) {
                let var_form_data = new FormData(this);

                // console.log(var_form_data);
                fetch("<?php echo ROOT_URL; ?>jQuery.php", {
                // fetch("", {
                    method: "POST",
                    body: var_form_data
                })
                .then(function (response) {
                    return response.text();
                })
                .then(function (text) {
                    // console.log(typeof(text));
                    if(text == '1' || text == '0') {
                        // console.log(text);
                        submit_button.addClass("disabled");
                        submit_button.attr("value","Added to Cart");
                        var cart_image = $('#cart img');
                        cart_image.attr("src", "<?php echo ROOT_URL; ?>assets/image/svg_icon/cart_true.svg");
                    } else if(text == '-1') {
                        alert("Something went wrong. Please contact us.");
                    } else {
                        console.log(text);
                    }
                })
                .catch(function (error) {
                    console.log(error);
                });

            };
            // submit_button.addClass("disabled");
            // submit_button.attr("value","Added to Cart");
            return false;
        });
    </script>
<?php } ?>