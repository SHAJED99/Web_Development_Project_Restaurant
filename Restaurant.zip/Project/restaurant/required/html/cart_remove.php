<?php if(isset($_SESSION['is_logged_in'])) { ?>
    <script>
        // $(".cart_del").click(function(){
        function del_cart(food_id){
            // food_id = $(this).attr('food_id');
            // console.log(food_id);

            let var_form_data = new URLSearchParams();
            var_form_data.append("food_id", food_id);
            var_form_data.append("jq_status", "cart_del");
            
            fetch("<?php echo ROOT_URL; ?>jQuery.php", {
            // fetch("", {
                method: "POST",
                body: var_form_data,
            })
            .then(function (response) {
                return response.text();
            })
            .then(function (text) {
                // console.log(text);
                // console.log(typeof(text));
                if(text == '1' || text == '0') {
                    $remaining_cart = $remaining_cart - 1;
                    if($remaining_cart < 1) {
                        $('#food_view').addClass('d-none');
                        var cart_image = $('#cart img');
                        cart_image.attr("src", "<?php echo ROOT_URL; ?>assets/image/svg_icon/cart_false.svg");
                        $('#empty_cart').addClass('d-block');
                        $('#empty_cart').removeClass('d-none');
                    };
                } else if(text == '-1') {
                    alert("Something went wrong. Please contact us.");
                }
            })
            .catch(function (error) {
                console.log(error);
            });
        };
    </script>
<?php } ?>