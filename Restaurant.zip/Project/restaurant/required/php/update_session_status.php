<?php 

function update_status($cart) {
    if(isset($cart) && isset($_SESSION['is_logged_in'])) {
        $cart->query('SELECT cart FROM customer WHERE mobile_number = :mobile_number');
        $cart->bind(':mobile_number', $_SESSION['user_id']);
        $temo_user_details = $cart->resultSet();
        $_SESSION['cart'] = array_management::creatArray($temo_user_details[0]['cart']);

        $temp_res = check_active_order($cart);

        if($temp_res != null) {
            if($temp_res[0]['order_id'] == null) {
                $_SESSION['last_order'] = false;
            } else {
                $_SESSION['last_order'] = true;
            }
        } else {
            $_SESSION['last_order'] = false;
        }
        // $_SESSION['last_order'] = check_active_order($cart)[0]['order_id'];
        // print_r(check_active_order($cart));
        // echo $_SESSION['last_order'];
    }
}

function check_active_order($cart) {
    $cart->query('SELECT order_id FROM order_list WHERE order_owner_number = :order_owner_number AND (order_status = :order_status1 or order_status = :order_status2 or order_status = :order_status3 or order_status = :order_status4)');
    $cart->bind(':order_owner_number', $_SESSION['user_id']);
    $cart->bind(':order_status1', "1");
    $cart->bind(':order_status2', "2");
    $cart->bind(':order_status3', "3");
    $cart->bind(':order_status4', "4");
    $res = $cart->resultSet();

    if(sizeof($res)){
        return $res;
    } else {
        return false;
    }
}