<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo ROOT_URL; ?>assets/css/bootstrap.min.css">
   <link rel="stylesheet" href="<?php echo ROOT_URL; ?>assets/css/owl.carousel.min.css">

    <link rel="stylesheet" href="<?php echo ROOT_URL; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo ROOT_URL; ?>assets/css/animate.min.css">
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo ROOT_URL; ?>assets/js/slim.min.js"></script>
    <script src="<?php echo ROOT_URL; ?>assets/js/popper.min.js"></script>
    <script src="<?php echo ROOT_URL; ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo ROOT_URL; ?>assets/js/owl.carousel.min.js"></script>
    <script src="<?php echo ROOT_URL; ?>assets/js/navbar.js"></script>
    <script src="<?php echo ROOT_URL; ?>assets/js/btn.js"></script>
    

    <title>
        <?php 
        if($_GET['controller'] == "") {
            echo COMPANY_NAME;
        } else {
            echo ucwords(COMPANY_NAME. " " .$_GET['controller']. "-" . ucwords($_GET['action']));;
        } ?>
    </title>
</head>

<body data-spy="scroll" data-target="#navbar" data-offset="50">

    <!-- --------------------------- Navbar -->
    
    <header class="fixed-top">
        <nav class="navbar navbar-expand-md navbar-dark container">
            <a class="logo" href="<?php echo ROOT_URL; ?>">
                <img src="<?php echo ROOT_URL; ?>assets/image/logo/logo.png" alt="LOGO"><?php echo COMPANY_NAME; ?>
            </a>

            <div class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <div class="option_btn position-relative">
                    <div class="dash_1 position-absolute"></div>
                    <div class="dash_2 position-absolute"></div>
                    <div class="dash_3 position-absolute"></div>
                </div>
            </div>
            
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="<?php echo ROOT_URL; ?>" id="nav_home"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/home.svg" alt="Home"></span>Home</a></li>

                    <?php if(isset($_SESSION['is_logged_in'])) {
                        if(isset($_SESSION['user_name']) && strlen($_SESSION['user_name']['last_name'])) { ?>
                            <li class="nav-item dropdown" id="navbarDropdownMenuLink"><a class="nav-link dropdown-toggle" id="users" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="<?php echo ROOT_URL; ?>users/login"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/login_true.svg" alt="login_true"></span><?php echo $_SESSION['user_name']['last_name']; ?></a>
                        <?php } else { ?>
                            <li class="nav-item dropdown" id="navbarDropdownMenuLink"><a class="nav-link dropdown-toggle" id="users" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="<?php echo ROOT_URL; ?>users/login"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/login_true.svg" alt="login_true"></span><?php echo $_SESSION['user_id']; ?></a>
                        <?php } ?>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <?php if(isset($_SESSION['cart']) && $_SESSION['cart']) { ?>
                                <a class="dropdown-item" href="<?php echo ROOT_URL; ?>users/cart" id="cart"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/cart_true.svg" alt="cart_true"></span>Cart</a>
                            <?php } else { ?>
                                <a class="dropdown-item" href="<?php echo ROOT_URL; ?>users/cart" id="cart"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/cart_false.svg" alt="cart_false"></span>Cart</a>
                            <?php } ?>

                            
                            <?php if(isset($_SESSION['last_order']) && $_SESSION['last_order']) { ?>
                                <a class="dropdown-item" href="<?php echo ROOT_URL; ?>users/order" id="order"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/order_true.svg" alt="cart_true"></span>Order</a>
                            <?php } else { ?>
                                <a class="dropdown-item" href="<?php echo ROOT_URL; ?>users/order" id="order"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/order_false.svg" alt="cart_false"></span>Order</a>
                            <?php } ?>

                            <?php if(isset($_SESSION['user_name']) && strlen($_SESSION['user_name']['first_name']) && strlen($_SESSION['user_name']['last_name']) && strlen($_SESSION['user_name']['email'])) { ?>
                                <a class="dropdown-item" href="<?php echo ROOT_URL; ?>users/details" id="details"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/user_true.svg" alt="details"></span>Edit your profile</a>
                            <?php } else { ?>
                                <a class="dropdown-item" href="<?php echo ROOT_URL; ?>users/details" id="details"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/user_false.svg" alt="details"></span>Edit your profile</a>
                            <?php } ?>

                            <a class="dropdown-item" href="<?php echo ROOT_URL; ?>users/logout"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/logout.svg" alt="logout"></span>Log-out</a>
                        </div>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo ROOT_URL; ?>users/login" id="login"><span><img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/login_false.svg" alt="login_false"></span>Log-in / Sign-up</a></li>
                    <?php } ?>
                </ul>
            </div>
        </nav>
    </header>

    <!-- --------------------------- -->
    <?php Messages::display(); ?>
    <?php require($view); ?>

    <script>sticky_navbar("header")</script>
    <script>$('#myModal').modal('show')</script>

    <script>

    <?php 
    if($_GET['controller'] == "") { ?>
        $("#nav_home").addClass("active disabled");
    <?php } elseif($_GET['controller'] == "users") { ?>
        $("#<?php echo $_GET['controller']; ?>").addClass("active");
        $("#<?php echo $_GET['action']; ?>").addClass("active disabled");
    <?php } ?>

    </script>
</body>
</html>