<section class="customer_order_section">
    <div class="container">
        <div class="upperspacing"></div>
        <div class="row pt-4">
            <div class="col-12 col-xl-2 col-md-3 d-block position-relative" id="cat_button_fild">
                <div class="d-flex flex-row flex-md-column pt-0 pt-md-4">
                    <div class="col-4 col-md-12 px-0">
                        <h6 class="w-100 d-flex justify-content-center justify-content-md-start align-items-center my-2 px-0 px-md-3 button_group active" onclick="get_data(this, '1')">Active Order</h6>
                    </div>
                    <div class="col-4 col-md-12 px-0">
                        <h6 class="w-100 d-flex justify-content-center justify-content-md-start align-items-center my-2 px-0 px-md-3 button_group" onclick="get_data(this, '0')">Previous Order</h6>
                    </div>
                    <div class="col-4 col-md-12 px-0">
                        <h6 class="w-100 d-flex justify-content-center justify-content-md-start align-items-center my-2 px-0 px-md-3 button_group" onclick="get_data(this, '-1')">Canceled Order</h6>
                    </div>
                </div>

                <div class="details position-absolute w-100 d-none d-md-flex flex-md-column text-center" id="total_order">
                    <div class="col-12 px-0">
                        <p class="w-100 my-2 px-0 px-md-3">Total Count: <span><?php echo sizeof($viewmodel) ?></span></p>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-9 col-xl-10 position-relative py-3 pl-md-4" id="detail_fild">

                <!-- --------------------------- Array Section -->
                
                <?php if(sizeof($viewmodel) > 0) {
                    foreach($viewmodel as $value) { ?>
                        
                    <div class="col-12 pt-1 px-0 d-flex justify-content-between" onclick="go_details('<?php echo $value['order_id'] ?>')">
                        <div class="col-6">
                            <h6 class="mb-1">Order Id: <span><?php echo $value['order_id'] ?></span></h6>

                            <?php
                                if ($value['order_status'] == 1) {
                                    $order_status = "Order Placed";
                                    $text_color = "text-info";
                                } elseif ($value['order_status'] == 2) {
                                    $order_status = "Processing";
                                    $text_color = "text-info";
                                } elseif ($value['order_status'] == 3) {
                                    $order_status = "Delivered";
                                    $text_color = "text-primary";
                                } elseif ($value['order_status'] == 4) {
                                    $order_status = "Waiting for payment";
                                    $text_color = "text-primary";
                                }
                            ?>
                            <p class="<?php echo $text_color ?> mb-1">Status: <span><?php echo $order_status ?></span></p>
                        </div>

                        <div class="col-auto">
                            <p class="text-secondary my-0 text-right">Date: <span class="date"><?php echo $value['DATE_FORMAT(time, "%d/%m/%Y")'] ?></span></p>
                            <p class="text-secondary my-0 text-right">Total bill: <span class="total_bill"><?php echo $value['total_cost'] ?></span> <?php echo CURRENCY; ?></p>
                        </div>
                    </div>
                    <div class="dash w-100 mb-2"></div>
                
                <?php }} else { ?> 
                    <div class="h-100 w-100 d-flex justify-content-center align-items-center">
                        <h4>No Item here</h4>
                    </div>
                <?php } ?>

                <!-- --------------------------- -->
            </div>
        </div>
    </div>
</section>

<script>
    btn_hover_bottom_border("#cat_button_fild h6.button_group", 'width', '0.2s');

    function go_details(order_id) {
        window.open("<?php echo ROOT_URL; ?>users/orderid/" + order_id);
    }

    function get_data(head, com) {
        let var_form_data = new URLSearchParams();
        var order_data = [];
        var obj = JSON.parse('{ "name":"John", "age":30, "city":"New York"}');
        
        var_form_data.append("com", com);
        var_form_data.append("jq_status", "order_cat");

        fetch("<?php echo ROOT_URL; ?>jQuery.php", {
            method: "POST",
            body: var_form_data,
        })
        .then(function (response) {
            return response.json();
        })
        .then(function (text) {
            $('#detail_fild').children().remove();
            // console.log(text.length);
            if (text != null && text.length > 0) {
                text.forEach(function(item){
                    // console.log(item);

                    var class_name;
                    var status_name;
                    if (item['order_status'] == 1) {
                        class_name = "text-info";
                        status_name = "Order Placed";
                    } else if (item['order_status'] == 2) {
                        class_name = "text-info";
                        status_name = "Processing";
                    } else if (item['order_status'] == 3) {
                        class_name = "text-primary";
                        status_name = "Delivered";
                    } else if (item['order_status'] == 4) {
                        class_name = "text-primary";
                        status_name = "Waiting for payment";
                    } else if (item['order_status'] == 0) {
                        class_name = "text-success";
                        status_name = "Paid";
                    } else if (item['order_status'] == -1) {
                        class_name = "text-warning";
                        status_name = "Canceled";
                    }

                    $('#detail_fild').append(
                        '<div class="col-12 pt-1 px-0 d-flex justify-content-between" onclick="go_details('+ item['order_id'] +')">' +
                        '<div class="col-6">' +
                        '<h6 class="mb-1">Order Id: <span>' + item['order_id'] + '</span></h6>' +
                        '<p class="' + class_name + ' mb-1">Status: <span>' + status_name + '</span></p>' +
                        '</div>' +
                        '<div class="col-auto">' +
                        '<p class="text-secondary my-0 text-right">Date: <span class="date">' + item['DATE_FORMAT(time, "%d/%m/%Y")'] + '</span></p>' +
                        '<p class="text-secondary my-0 text-right">Total bill: <span class="total_bill">' + item['total_cost'] + '</span> <?php echo CURRENCY; ?></p>' +
                        '</div>' +
                        '</div>' +
                        '<div class="dash w-100 mb-2"></div>'
                    );

                    $('#total_order p>span').text(text.length);
                })
            } else {
                $('#detail_fild').append(
                    '<div class="h-100 w-100 d-flex justify-content-center align-items-center">' +
                    '<h4>No Item here</h4>' +
                    '</div>'
                )

                $('#total_order p>span').text('0');
            }
        })
        .catch(function (error) {
            console.log(error);
        });
        
        $(head).addClass('active');
        $(head).parent().siblings().find(".button_group").removeClass('active');
    }
</script>