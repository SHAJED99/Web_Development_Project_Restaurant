function sticky_navbar(header) {
    var main_class = $(header);

    var distance = (main_class.offset().top - $('body').offset().top);
    main_function();

    $(window).scroll(main_function);

    function main_function() {
        var scroll = $(window).scrollTop();

        if (scroll > distance) {
            main_class.addClass('header_sticky');
            $(header + '.header_sticky').css({
                // 'position': 'fixed',
                'z-index': '9',
                'width': '100%',
            });
        } else {
            $(header + '.header_sticky').css({
                // 'position': 'static',
                'z-index': '9',
                'width': 'inherit',
            })
            main_class.removeClass('header_sticky');
        }
    }
}

function scroll_spy(header, custom_offset = 0, last_element = true) {
    var elems = $('*[id]');
    var max = 0;
    var body_bottom = $(document).height();
    main_munction();
    $(window).scroll(main_munction);

    function main_munction() {
        var currentTop = $(window).scrollTop();
        var currentBottom = currentTop + $(window).height();

        elems.each(function() {
            var elemTop = $(this).offset().top - custom_offset;
            var elemBottom = elemTop + $(this).height();

            if (last_element && max < elemBottom) {
                max = elemBottom;
            }

            if (last_element && (body_bottom <= currentBottom || Math.abs(body_bottom - currentBottom) < 1)) {
                var id = $(this).attr('id');
                var navElem = $(header + ' a[href="#' + id + '"]');
                navElem.addClass('active');
                navElem.parent().siblings().children().removeClass('active');


            } else if (currentTop >= elemTop && currentTop <= elemBottom) {
                var id = $(this).attr('id');
                var navElem = $(header + ' a[href="#' + id + '"]');
                navElem.addClass('active');
                navElem.parent().siblings().children().removeClass('active');
            }
        });
    };
}