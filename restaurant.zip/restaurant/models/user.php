<?php 
class UserModel extends Model{
    public function login(){
        if($_SERVER["REQUEST_METHOD"] == "POST"){
            $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            //Login Form
            if(isset($post['login_submit'])){
                if(strlen($post['number']) == 11 && $post['number'][0] == '0' && $post['number'][1] == '1'){
                    $this->query('SELECT * FROM customer_loginform WHERE mobile_number = :mobile_number AND password = :password');
                    $this->bind(':mobile_number', $post['number']);
                    $this->bind(':password', md5($post['password']));

                    $temp_row = $this->resultSet();
                    if(sizeof($temp_row) == 1) {
                        //Successfull
                        $_SESSION['is_logged_in'] = true;
                        $_SESSION['user_id'] = $post['number'];

                        $this->query('SELECT * FROM customer WHERE mobile_number = :mobile_number');
                        $this->bind(':mobile_number', $post['number']);
                        $temo_user_details = $this->resultSet();
                        // print_r($temo_user_details);

                        $_SESSION['user_name'] = array(
                            'first_name' => ucwords($temo_user_details[0]['first_name']),
                            'last_name' => ucwords($temo_user_details[0]['last_name']),
                            'email' => $temo_user_details[0]['email']
                        );

                        // $_SESSION['cart'] = array_management::creatArray($temo_user_details[0]['cart']);

                        // if($temo_user_details[0]['last_order'] == null) {
                        //     $_SESSION['last_order'] = false;
                        // } else {
                        //     $_SESSION['last_order'] = true;
                        // }

                        update_status($this);
                        
                        header('Location: '.ROOT_URL);
                    } elseif (sizeof($temp_row) > 1) {
                        Messages::setMsg("Somthing went wrong with this mobile number. Please contact with the administrator.", "error");
                    } else {
                        Messages::setMsg("Wrong mobile number and password.", "error");
                    }
                } else {
                    Messages::setMsg("Invalid mobile number.", "error");
                }
            }

            //Signup Form
            elseif(isset($post['signup_submit'])){
                if(strlen($post['new_number']) == 11 && $post['new_number'][0] == '0' && $post['new_number'][1] == '1'){
                    $this->query('SELECT * FROM customer_loginform WHERE mobile_number = :mobile_number');
                    $this->bind(':mobile_number', $post['new_number']);
                    $temp_UserModel = $this->resultset();
                    if(sizeof($temp_UserModel) != 0) {
                        Messages::setMsg("This username is already in use. Please contact we the administrator.", "error");
                    }
                    elseif($post['new_password'] != $post['r_password']) {
                        Messages::setMsg("Confirm your password", "error");
                    }
                    else {
                        //Getting previous totel members
                        $previous_value = $this->lastInsertIdNormal_start("customer_loginform");
                        echo $previous_value;

                        //Insert into mysql
                        $this->query('INSERT INTO customer_loginform (mobile_number, password) VALUES(:mobile_number, :password)');
                        $this->bind(':mobile_number', $post['new_number']);
                        $this->bind(':password', md5($post['new_password']));
                        $this->execute();
                        
                        //Verify
                        if($this->lastInsertIdNormal_end("customer_loginform", $previous_value)){
                            $this->query('INSERT INTO customer (mobile_number) VALUES(:mobile_number)');
                            $this->bind(':mobile_number', $post['new_number']);
                            $this->execute();
                            $_SESSION['is_logged_in'] = true;
                            $_SESSION['user_id'] = $post['new_number'];
                            header('Location: '.ROOT_URL.'users/details');
                        } else {
                            Messages::setMsg("Registration fail. Please contact we the administrator.", "error");
                        }
                    }
                } else {
                    Messages::setMsg("Invalid mobile number.", "error");
                }
            }
        }
        return;
    }

    public function details(){
        if($_SERVER["REQUEST_METHOD"] == "POST"){
            $post = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);
            if($post['imformation_submit']){
                $this->query('UPDATE customer SET first_name=:first_name, last_name=:last_name, email=:email WHERE mobile_number=:mobile_number');

                $this->bind(':mobile_number', $_SESSION['user_id']);
                $this->bind(':first_name', strtolower($post['first_name']));
                $this->bind(':last_name', strtolower($post['last_name']));
                $this->bind(':email', $post['email']);
                $this->execute();
                $_SESSION['user_name'] = array(
                    'first_name' => ucwords(strtolower($post['first_name'])),
                    'last_name' => ucwords(strtolower($post['last_name'])),
                    'email' => $post['email']
                );
                header('Location: '.ROOT_URL, false);
            }
        }
        return;
    }

    public function cart() {
        update_status($this);

        if($_SESSION['cart']) {
            $result = array();
            foreach ($_SESSION['cart'] as $value) {
                // echo $value;
                $this->query('SELECT food_id, food_name, price, status, image_location, type FROM food_list_post WHERE food_id = :food_id');
                $this->bind(':food_id', $value);
                $res = $this->resultSet();
                if(!sizeof($res)) {
                    $res = array(0 => array('food_id' => $value));
                }
                // print_r($tr);
                array_push($result, $res);
            }
            $this->query('SELECT total_seat_number FROM shop_other_variable');
            $res = $this->resultSet();
            $result =array($result, $res);
            return $result;
        }
    }

    public function order() {
        $this->query('SELECT order_id, order_status, DATE_FORMAT(time, "%d/%m/%Y"), total_cost FROM order_list WHERE order_owner_number = :order_owner_number AND (order_status = :order_status1 OR order_status = :order_status2 OR order_status = :order_status3 OR order_status = :order_status4) ORDER BY order_status DESC, time DESC, order_id DESC');
        $this->bind(':order_owner_number', $_SESSION['user_id']);
        $this->bind(':order_status1', "1");
        $this->bind(':order_status2', "2");
        $this->bind(':order_status3', "3");
        $this->bind(':order_status4', "4");
        $row = $this->resultSet();
        // print_r($row);
        return $row;
    }

    public function orderid($id) {
        $this->query('SELECT order_id, order_status, DATE_FORMAT(time, "%d/%m/%Y"), DATE_FORMAT(time, "%h:%i %p"), total_cost, address, items, items_amount FROM order_list WHERE order_owner_number = :order_owner_number AND order_id = :order_id');
        $this->bind(':order_owner_number', $_SESSION['user_id']);
        $this->bind(':order_id', $id);
        $row = $this->resultSet();
        // print_r($row);
        

        
        // print_r($row);

        if($row != null){
            $result = array();

            $food = array_management::creatArray($row[0]['items']);
            $food_quantity = array_management::creatArray($row[0]['items_amount']);

        
            foreach ($food as $key => $value) {
                $this->query('SELECT food_id, food_name, price, status, image_location, type FROM food_list_post WHERE food_id = :food_id');
                $this->bind(':food_id', $value);
                $res = $this->resultSet();
                if(!sizeof($res)) {
                    $res = array(0 => array('food_id' => $value));
                }
                array_push($res, $food_quantity[$key]);
                array_push($result, $res);
            }
            $row = array($result, $row);
            return $row;
        } else {
            return false;
        }
    }
}