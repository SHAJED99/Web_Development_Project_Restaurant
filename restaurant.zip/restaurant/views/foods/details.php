
<section class="food_detail">
    <div class="effect" style="background-image: url('<?php echo ROOT_URL.$viewmodel[0][0]['image_location']; ?>');"></div>
    <div class="container" >
        <div class="upperspacing"></div>
        <div class="row">
            <div class="col-md-12 col-lg-6 d-flex justify-content-center align-items-center">
                <div class="image_div">
                    <img src="<?php echo ROOT_URL.$viewmodel[0][0]['image_location']; ?>" alt="<?php echo $viewmodel[0][0]['type']; ?>">
                </div>
            </div>

            <div class="col-md-12 col-lg-6">
                <h5 class="card-title"><?php echo $viewmodel[0][0]['food_name']; ?></h5>
                <div class="bar"></div>
                <P class="product_id d-flex flex-wrap"><span class="col-12 col-md-6">Product ID: <?php echo $viewmodel[0][0]['food_id']; ?></span><span class="col-12 col-md-6">Type: <?php echo str_replace("_", " ", ucfirst($viewmodel[0][0]['type'])); ?></span></P>
                <p><?php echo $viewmodel[0][0]['food_details']; ?></p>

                <div class="star_rating">
                    <?php GraphicalRepresentation::showRatingStar($viewmodel[0][0]['food_rating']); ?>
                    <p class="d-inline-block m-0">(<?php echo $viewmodel[0][0]['food_rating']; ?>/5)</p>
                </div>
                <p class="price_tag">Price: <?php echo $viewmodel[0][0]['price'].' '.CURRENCY; ?></p>


                <?php if($viewmodel[0][0]['status']) { ?>
                    <?php if(isset($_SESSION['is_logged_in'])) { 
                        if($_SESSION['cart']) {
                            if(!in_array($viewmodel[0][0]['food_id'], $_SESSION['cart'])) { ?>
                                <form>
                                    <input class="d-none" name="jq_status" type="text" value="cart_add">
                                    <input class="d-none" name="food_id" type="text" value="<?php echo $viewmodel[0][0]['food_id'] ?>">
                                    <input class="btn btn-primary" name="add_cart" type="submit" value="Add to Cart">  
                                </form>
                            <?php } else { ?>
                                <a href="<?php echo ROOT_URL; ?>users/cart" class="btn btn-primary disabled">Added to Cart</a>
                        <?php } } else { ?>
                            <form>
                                <input class="d-none" name="jq_status" type="text" value="cart_add">
                                <input class="d-none" name="food_id" type="text" value="<?php echo $viewmodel[0][0]['food_id'] ?>">
                                <input class="btn btn-primary" name="add_cart" type="submit" value="Add to Cart">  
                            </form>
                        <?php }} else { ?>
                            <a href="<?php echo ROOT_URL; ?>users/login" class="btn btn-primary">Order</a>
                        <?php } ?>
                        <?php if($viewmodel[0][0]['status'] <= 10) { ?>
                            <p class="text-danger d-inline-block"><?php echo $viewmodel[0][0]['status']; ?> left</p>
                        <?php } ?>
                    <?php } else { ?>
                        <a href="#" class="btn btn-primary disabled">Not available</a>
                <?php } ?>
            </div>
        </div>
        <div class="upperspacing"></div>

        <?php if(sizeof($viewmodel[1])) { ?>
        <div class="row">
            <div class="col-12">
                <h6>Recommended:</h6>
            </div>
            <div class="col-12">
                <div class="owl-carousel owl-theme" id="recom_food_carousel">
                    <?php foreach ($viewmodel[1] as $value) { ?>
                    <div class="item" style="background-image: url('<?php echo ROOT_URL.$value['image_location']; ?>');"><a href="<?php echo ROOT_URL; ?>foods/details/<?php echo $value['food_id']?>">
                        <p class="title"><?php echo $value['food_name']; ?> <span><?php GraphicalRepresentation::showRatingStar($value['food_rating']); ?> (<?php echo $value['food_rating']; ?>/5)</span></p>
                        <p class="price"><?php echo $value['price'].' '.CURRENCY; ?></p>
                    </a></div>
                    <?php } ?>
                </div>
            </div>
        </div>
        <div class="upperspacing"></div>
        <?php } ?>
    </div>
</section>



<!-- JQUERY -->
<?php require('required/html/cart_add.php'); ?>

<?php 
    $recom_item_size = sizeof($viewmodel[1]);
    if($recom_item_size) {
        if($recom_item_size < 5) {
            $scr_300 = (int)(2 / 5 * $recom_item_size);
            $scr_600 = (int)(3 / 5 * $recom_item_size);

            $scr_300 = ($scr_300 == 0) ? 1 : $scr_300;
            $scr_600 = ($scr_600 == 0) ? 1 : $scr_600;
        } else {
            $scr_300 = 2;
            $scr_600 = 3;
            $recom_item_size = 5;
        }
    ?>
        <script>
            $('#recom_food_carousel').owlCarousel({
                loop: true,
                center: true,
                margin: 10,
                nav: false,
                dots: false,
                URLhashListener: false,
                startPosition: 'URLHash',
                autoHeight: true,
                autoplay:true,
                autoplayTimeout:2000,
                autoplayHoverPause:true,
                responsive:{
                    0:{
                        items:1
                    },
                    300:{
                        items:<?php echo $scr_300; ?>
                    },
                    600:{
                        items:<?php echo $scr_600; ?>
                    },
                    1000:{
                        items:<?php echo $recom_item_size; ?>
                    }
                },
            })
        </script>
<?php } ?>