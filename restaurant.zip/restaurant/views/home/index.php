<section class="banner">
    <div id="banner" class="carousel slide" data-ride="carousel" data-interval="2000" data-pause="hover">
        <!-- SLIDER -->
        <ol class="carousel-indicators">
            <?php 
                $temp = 0;
                foreach ($viewmodel[0] as $value) {
                    if ($temp == 0) {
                        echo '<li data-target="#banner" data-slide-to="'.$temp.'" class="active"></li>';
                    } else {
                        echo '<li data-target="#banner" data-slide-to="'.$temp.'"></li>';
                    }
                    $temp = $temp + 1;
                }
            ?>
        </ol>

        <div class="carousel-inner">
            <?php 
                $temp = 0;
                foreach ($viewmodel[0] as $value) {
                    if ($temp == 0) {
                        echo '<div class="carousel-item active">';
                    } else {
                        echo '<div class="carousel-item">';
                    }
                    $temp = $temp + 1;

                    ?>
                        <img src="<?php echo $value['image']; ?>" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-md-block text-left custom">
                            <h1><?php echo $value['title']; ?></h1>

                            <p><?php echo $value['sub_title']; ?></p>
                        </div>
                    </div>
                    <?php 
                }
            ?>
        </div>

        <!-- CONTROLER -->

        <?php if (sizeof($viewmodel[0]) > 1) { ?>
        <a class="carousel-control-prev" href="#banner" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#banner" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
        <?php } ?>
    </div>
</section> 

<section class="card_section">
    <div class="container">
        <div class="upperspacing w-100"></div>
        <?php 
        $type = array();
        if(sizeof($viewmodel[1])) { ?>
            <div class="filters">
                <div class="ui-group">
                    <div class="button-group filters-button-group" data-filter-group="available">
                        <button class="custom_btn button is-checked" data-filter="*">All</button>
                        <button class="custom_btn button" data-filter=".available">Available</button>
                    </div>

                    <input class="form-control col-6 col-md-4" id="myInput" type="text" placeholder="Search..">
                </div>

                <div class="ui-group">
                    <div class="button-group filters-button-group" data-filter-group="type">
                        <button class="custom_btn button is-checked" data-filter="*">All</button>
                        <?php foreach ($viewmodel[1] as $value) {
                            if(!in_array($value['type'], $type)) {
                                $str = str_replace("_", " ", ucfirst($value['type'])); ?>
                                <button class="custom_btn button" data-filter=".<?php echo $value['type']; ?>"><?php echo $str; ?></button>
                                <?php array_push($type, $value['type']); 
                            } 
                        } ?>
                    </div>
                </div>
            </div>
            
            

            <div class="row justify-content-center justify-content-sm-start grid" id="myTable">
                <?php foreach ($viewmodel[1] as $value) { ?>

                <!-- <form action="#" method="POST"> -->
                <div class="col-12 col-lg-3 col-md-4 col-sm-6 element-item <?php echo $value['type']; if($value['status']) { echo " available"; }?>">
                <form>
                    <div class="content d-flex justify-content-center">
                        <div class="card">
                            <img class="card-img-top" src="<?php echo ROOT_URL.$value['image_location']; ?>" alt="<?php echo $value['type']; ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $value['food_name']; ?></h5>
                                <?php $str = implode(' ', array_slice(explode(' ', $value['food_details']), 0, 15)).'...'; ?>
                                <p class="card-text"><?php echo $str; ?><span><a href="<?php echo ROOT_URL; ?>foods/details/<?php echo $value['food_id']?>">Read More</a></span></p>
                                <div class="rating d-flex align-items-center">
                                    <?php GraphicalRepresentation::showRatingStar($value['food_rating']); ?>
                                    <p class="d-inline-block m-0">(<?php echo $value['food_rating']; ?>/5)</p>
                                </div>
                                <p class="price_tag">Price: <?php echo $value['price'].CURRENCY; ?></p>


                                <!-- 1. IF PRODUCT AVAILABLE -->
                                <?php if($value['status']) { ?>

                                    <!-- 2. IF LOGGED IN -->
                                    <?php if(isset($_SESSION['is_logged_in'])) { 

                                        // 3. IF CART ARRAY SET
                                        if($_SESSION['cart']) {

                                            // 4. IF IN CART ARRAY
                                            if(!in_array($value['food_id'], $_SESSION['cart'])) { ?>
                                                <input class="d-none" name="jq_status" type="text" value="cart_add">
                                                <input class="d-none" name="food_id" type="text" value="<?php echo $value['food_id'] ?>">
                                                <input class="btn btn-primary" name="add_cart" type="submit" value="Add to Cart">    
                                            
                                            <!-- 4. IF NOT IN CART ARRAY -->
                                            <?php } else { ?>
                                                <a href="<?php echo ROOT_URL; ?>users/cart" class="btn btn-primary disabled">Added to Cart</a>
                                        
                                        <!-- 3. IF CART ARRAY NOT SET -->
                                        <?php }} else { ?>
                                            <input class="d-none" name="jq_status" type="text" value="cart_add">
                                            <input class="d-none" name="food_id" type="text" value="<?php echo $value['food_id'] ?>">
                                            <input class="btn btn-primary" name="add_cart" type="submit" value="Add to Cart">  

                                    <!-- 2. IF NOT LOGGED IN -->
                                    <?php } } else { ?>
                                        <a href="<?php echo ROOT_URL; ?>users/login" class="btn btn-primary">Order</a>
                                    <?php } ?>

                                    <!-- 2. SHOW LAST AVAILABLE ITEMS -->
                                    <?php if($value['status'] <= 10) { ?>
                                        <p class="text-danger d-inline-block"><?php echo $value['status']; ?> left</p>
                                    <?php } ?>

                                <!-- 1. IF PRODUCT NOT AVAILABLE -->
                                <?php } else { ?>
                                    <a href="#" class="btn btn-primary disabled">Not available</a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </form>
                </div>
                <?php } ?>
            </div>
        <?php } else {?>
            <h2 class="text-white text-center">Nothing to show. Please try again later</h2>
        <?php } ?>
        <div class="upperspacing w-100"></div>
    </div>
</section>








<!-- JQUERY -->
<?php require('required/html/cart_add.php'); ?>

<script>
    make_visible();
    // Button Select
    $('.filters .ui-group .button-group button').click(function(){
        data_filter = $(this).attr('data-filter');
        $(this).addClass('is-checked');
        $(this).siblings().removeClass('is-checked');
        make_visible();
    })

    // Make Div Visible
    function make_visible() {
        keep_visible = [];
        $('.filters .ui-group .button-group').each(function(){
            data_filter = $(this).find('.is-checked').attr('data-filter');
            if(data_filter == "*"){
                data_filter = "";
            }
            keep_visible.push(data_filter);
        })
        keep_visible_str = String(keep_visible[0] + keep_visible[1]);
        // console.log(keep_visible_str);
        visible_class = $('.element-item'+keep_visible_str);
        visible_class.siblings().addClass('d-none');
        visible_class.removeClass('d-none');
    }

    // Add Effect
    $('.element-item').css('transition', '0.5s');
    
</script>

<script>
    $(document).ready(function(){
        $("#myInput").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            $("#myTable .element-item").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
        });
    });
</script>
