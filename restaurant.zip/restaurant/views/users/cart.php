<div id="custom_modal"></div>
<section class="cart_section">
    <div class="container">
    <div class="upperspacing"></div>
        <div class="row">
            <?php if(isset($viewmodel[0])) { ?>
            <script>$remaining_cart = <?php echo sizeof($viewmodel[0]); ?></script>
            <div class="w-100 my-4 table" id="food_view">
                <div class="d-none d-md-flex justify-content-between py-2 tr">
                    <div class="preserve_area th"></div>
                    <div class="w-50 th"><h5>Product</h5></div>
                    <div class="w-50 th">
                        <div class="row justify-content-around">
                            <h5 class="col-4">Price</h5>
                            <h5 class="col-4">Quantity</h5>
                            <h5 class="col-4">Sub-total</h5>
                        </div>
                    </div>
                    <!-- <th class="w-25"></th> -->
                    <div class="preserve_area th"></div>
                </div>


                <!-- product_show -->
                <?php foreach ($viewmodel[0] as $value) {
                    if(sizeof($value[0]) > 1) { ?>
                    <div class="d-flex py-1 tr cart_food">
                        <!-- check_box -->
                        <div class="preserve_area td">
                            <?php if($value[0]['status']) { ?>
                            <input type="checkbox" class="food_select">
                            <?php } ?>
                        </div>
                        <!-- Name and detail -->
                        <div class="w-50 td">
                            <a class="d-flex" href="<?php echo ROOT_URL; ?>foods/details/<?php echo $value[0]['food_id']?>" target="_blank">
                                <div class="product_img">
                                    <img src="<?php echo ROOT_URL.$value[0]['image_location']; ?>" alt="<?php echo $value[0]['type']; ?>">
                                </div>
                                <div class="product_details px-2">
                                    <p class="food_name">Food name: <span><?php echo $value[0]['food_name']; ?></span></p>
                                    <p class="type">Food type: <?php echo str_replace("_", " ", ucfirst($value[0]['type'])); ?></p>
                                    <p class="food_id">Food ID: <span><?php echo $value[0]['food_id']; ?></span></p>
                                </div>
                            </a>
                        </div>

                        
                        <div class="w-50 td">
                            <div class="row justify-content-around flex-wrap align-items-center h-100">
                                <!-- Price -->
                                <div class="d-flex justify-content-between justify-content-md-center align-items-center col-12 col-md-4">
                                    <p class="my-0 d-inline-block d-md-none col-6 text-left">Price: </p>
                                    <p class="my-0 col-6 col-md-12 text-right text-md-center price"><?php echo $value[0]['price']; ?> <span><?php echo CURRENCY; ?></span></p>
                                </div>
                                <!-- Quantity -->
                                <div class="d-flex justify-content-between justify-content-md-center align-items-center col-12 col-md-4">
                                    <p class="my-0 d-inline-block d-md-none col-6 text-left">Quantity: </p>
                                    <p class="my-0 col-6 col-md-12 text-right text-md-cente">
                                        <?php if($value[0]['status']) { ?>
                                        <select class="select_quantity">
                                            <?php foreach (range(1, 10) as $i) { 
                                                if($i <= $value[0]['status']) { ?>
                                                <option value=<?php echo $i ?>><?php echo $i ?></option>
                                            <?php } } ?>
                                        </select>
                                        <?php } else { ?>
                                            Not available
                                        <?php } ?>
                                    </p>
                                </div>
                                <!-- Sub-total -->
                                <div class="d-flex justify-content-between justify-content-md-center align-items-center col-12 col-md-4">
                                    <p class="my-0 d-inline-block d-md-none col-6 text-left">Sub-Total: </p>
                                    <p class="my-0 col-6 col-md-12 text-right text-md-center sub-Total"><?php echo $value[0]['price']; ?> <span><?php echo CURRENCY; ?></span></p>
                                </div>
                            </div>
                        </div>
                        <!-- check_box -->
                        <div class="preserve_area td">
                            <button class="cart_del" food_id="<?php echo $value[0]['food_id'] ?>">X</button>
                        </div>
                        
                    </div>

                    <?php } else { ?>
                    <div class="d-flex justify-content-between py-1 cart_food tr">
                        <div class="w-100 td">
                            <p class="d-flex align-items-center h-100 m-0 pl-4">Product information is not available</p>
                        </div>
                        <div class="preserve_area td">
                        <button class="cart_del" food_id="<?php echo $value[0]['food_id'] ?>">X</button>
                        </div>
                    </div>
                    <?php } ?>
                <?php } ?>

                <div class="container py-1 total_div">
                    <div class="row justify-content-between">
                        <div class="d-flex justify-content-between align-items-center td">
                            <div class="preserve_area">
                                <input type="checkbox" id="select_all">
                            </div>
                            <label class="form-check-label d-inline-block ml-2" for="select_all">Select All</label>
                        </div>
                        <div class="d-flex align-items-center mr-2">
                            <div class="d-flex justify-content-center align-items-end flex-column mr-2">
                                <p class="m-0">Sub-Total: <span id="Sub_Total">0</span> <?php echo CURRENCY; ?></p>
                                <p class="m-0">Discount: <span id="discount">0</span> <?php echo CURRENCY; ?></p>
                                <h1 class="m-0">Total: <span id="total">0</span> <?php echo CURRENCY; ?></h1>
                            </div>
                            <a class="d-flex justify-content-center align-items-center px-2 px-md-4 h-75" id="check_out">Check Out</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 d-none" id="empty_cart">
                <div class="empty-cart d-flex align-items-center justify-content-center flex-column">
                    <img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/empty-cart.svg" alt="empty-cart">
                </div>
            </div>
            <?php } else { ?>
            <div class="col-12">
                <div class="empty-cart d-flex align-items-center justify-content-center flex-column">
                    <img src="<?php echo ROOT_URL; ?>assets/image/svg_icon/empty-cart.svg" alt="empty-cart">
                </div>
            </div>
            <?php } ?>
        </div>
    </div>
</section>

<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" id="checkout_modalmodal" data-target="#checkout_modalexampleModalLong">
  Launch demo modal
</button> -->

<section class="checkout_modal position-relative">
    <!-- Modal -->
    <div class="modal fade" id="checkout_modalexampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title text-info" id="exampleModalLongTitle">Confirm your order:</h4>
                    <button type="button" class="close" aria-label="Close" onclick="closemodal()">
                    <span aria-hidden="true" class="text-light">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- MODAL BOX -->
                    <div class="table text-center m-0">
                        <!-- TABLE HEAD -->
                        <div class="tr d-flex justify-content-between">
                            <div class="th col-3 text-warning">
                                <p class="my-1">Product</p>
                            </div>
                            <div class="th col-3 text-warning">
                                <p class="my-1">Quantity</p>
                            </div>
                            <div class="th col-3 text-warning">
                                <p class="my-1">Price</p>
                            </div>
                            <div class="th col-3 text-warning">
                                <p class="my-1">Total</p>
                            </div>
                            
                        </div>
                        <div class="dash w-100"></div>

                        <!-- PRODUCT LIST -->
                        <div id="checkout_modal_table">
                            
                        </div>

                        <!-- GRAND TOTAL -->
                        <div class="tr d-flex justify-content-between align-items-center text-left text-nowrap my-1">
                            <div class="td col-12">
                                <p class="my-0">Sub Total: <span id="checkout_modal_table_Sub_Total"></span> <?php echo CURRENCY; ?></p>
                                <p class="my-0">Discount: <span  id="checkout_modal_table_discount"></span> <?php echo CURRENCY; ?></p>
                                <p class="my-0">Grand Total: <span  id="checkout_modal_table_total"></span> <?php echo CURRENCY; ?></p>

                                <div class="d-flex align-items-center my-2">
                                    <input type="radio" id="delivery_place_in" value="in" name="delivery_place" checked>
                                    <label for="delivery_place_in" class="my-0 mx-2">In Restaurant</label>

                                    <!-- seat number -->
                                    <select name="seat_number" id="seat_number">
                                        <option value="0">Seat Number</option>
                                        <?php if (isset($viewmodel[1][0]['total_seat_number'])) {
                                            for ($x = 1; $x <= $viewmodel[1][0]['total_seat_number']; $x++) { ?>
                                                <option value="<?php echo $x ?>"><?php echo $x ?></option>
                                            <?php } ?>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="d-flex align-items-center my-2">
                                    <input type="radio" id="delivery_place_out" value="out" name="delivery_place" disabled>
                                    <label for="delivery_place_out" class="my-0 ml-2">Somewhere else <span class="text-secondary">(This is not available now)</span></label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- MODAL BOX END -->
                </div>
                <div class="modal-footer m-0 p-1">
                    <a class="d-flex justify-content-center align-items-center  px-2 px-md-4 h-75" id="Confirm_order">Confirm Order</a>
                </div>
            </div>
        </div>
    </div>
</section>



<?php require('required/html/cart_remove.php'); ?>

<!-- JQuary -->
<?php if(isset($_SESSION['is_logged_in']) && isset($viewmodel[0])) { ?>
    <script>
        $('.cart_del').click(function() {
            $(this).parents('.cart_food').remove();
            // $(this).parents('.cart_food').removeClass('d-flex');
            del_cart($(this).attr('food_id'));
        })
        btn_hover_bubble_effect('#Confirm_order');
    </script>
<?php } ?>


<?php if(isset($_SESSION['is_logged_in']) && isset($viewmodel[0])) { ?>
<script>
    // CHECK OUT BUTTON
    btn_hover_bubble_effect('#check_out');

    function active_checkout_button() {
        if(parseFloat($('#total').text()) > 0) {
            $('#check_out').addClass('active');
        } else {
            $('#check_out').removeClass('active');
        }
    }

    $('#check_out').click(function(){
        $('#myModal').remove();
        if($(this).hasClass('active')){
            food_list = [];
            food_quantity = [];
            $('#checkout_modal_table').html('');
            $(".cart_food").each(function(index) {
                if(!$(this).hasClass('d-none')) {
                    if($(this).find('input.food_select').is(":checked")){
                        food_list.push(parseInt($(this).find('p.food_id span').text()));
                        food_quantity.push(parseInt($(this).find('select.select_quantity').val()));

                        // creating info
                        $('#checkout_modal_table').append(
                            '<div class="tr d-flex justify-content-between align-items-center my-1">'+
                            '<div class="td col-3">'+
                            '<p class="my-0 checkout_modal_product">Product: <span>'+$(this).find('p.food_name>span').text()+'</span></p>'+
                            '<p class="my-0 checkout_modal_id">ID: <span>'+$(this).find('p.food_id span').text()+'</span></p>'+
                            '</div>'+

                            '<div class="td col-3">'+
                            '<p class="my-0 checkout_modal_price">'+$(this).find('p.price').text()+'</p>'+
                            '</div>'+

                            '<div class="td col-3">'+
                            '<p class="my-0 checkout_modal_quantity">'+$(this).find('select.select_quantity').val()+'</p>'+
                            '</div>'+
                            
                            '<div class="td col-3">'+
                            '<p class="my-0 checkout_modal_Total">'+$(this).find('p.sub-Total').text()+'</p>'+
                            '</div>'+
                            '</div>'+
                            '<div class="dash w-100 mb-2"></div>'
                        )
                    }
                };
            });

            $("#checkout_modal_table_Sub_Total").html($("#Sub_Total").text());
            $("#checkout_modal_table_discount").html($("#discount").text());
            $("#checkout_modal_table_total").html($("#total").text());

            $("#checkout_modalexampleModalLong").modal({backdrop: 'static', keyboard: false}, "show");
  
            let var_form_data = new URLSearchParams();


            if (food_list.length > 0 && $("#seat_number").val() != "0") {
                $("#Confirm_order").addClass('active');
            } else {
                $("#Confirm_order").removeClass('active');
            }
            
            $("#Confirm_order").click(function(){
                if (food_list.length > 0 && $(this).hasClass('active')) {
                    // console.log(food_list);
                    var_form_data.append("food_list", food_list);
                    var_form_data.append("food_quantity", food_quantity);
                    var_form_data.append("order_place", $('input[name="delivery_place"]:checked').val() + " " + $("#seat_number").val());
                    var_form_data.append("jq_status", "check_out");

                    // console.log(var_form_data);

                    fetch("<?php echo ROOT_URL; ?>jQuery.php", {
                    // fetch("", {
                        method: "POST",
                        body: var_form_data,
                    })
                    .then(function (response) {
                        return response.json();
                    })
                    .then(function (text) {
                        console.log(text);
                        // console.log(Array.isArray(text));

                        if(!Array.isArray(text)) {
                            if (text == "true") {
                                window.open("<?php echo ROOT_URL; ?>users/order", "_SELF");
                            } else if (text == "false") {
                                console.log("Something went wrong");
                            } else {
                                $('#custom_modal').append(
                                    '<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="myModal">' +
                                        '<div class="modal-dialog modal-lg">'+
                                            '<div class="modal-content">'+
                                                '<div class="alert alert-danger">'+text+'</div>'+
                                            '</div>'+
                                        '</div>'+
                                    '</div>'
                                )
                                $('#myModal').modal('show');
                            }
                        } else {
                            // console.log(text);
                            $('#custom_modal').append(
                                '<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="myModal">' +
                                    '<div class="modal-dialog modal-lg">'+
                                        '<div class="modal-content">'+
                                            '<div class="alert alert-danger">You have a previous active order. <a class="text-primary" href="<?php echo ROOT_URL; ?>users/orderid/' + text[0]['order_id'] + '">(Order ID: ' + text[0]['order_id'] + ')</a><br>Please complete active order before placing another order.</div>'+
                                        '</div>'+
                                    '</div>'+
                                '</div>'
                            )
                            $('#myModal').modal('show');
                        }
                    })
                    .catch(function (error) {
                        console.log(error);
                    });
                    food_list = [];
                    $("#checkout_modalexampleModalLong").modal("hide");
                }
            });
        }
    })

    $("#seat_number").change(function(){
        if ($("#seat_number").val() != "0") {
            $("#Confirm_order").addClass('active');
        } else {
            $("#Confirm_order").removeClass('active');
        }
    })

    // close modal 
    function closemodal(){
        $("#checkout_modalexampleModalLong").modal("hide");
    }

    // CHECK TOTAL
    function count_total_value() {
        $total = 0;
        $(".cart_food").each(function(index) {
            if(!$(this).hasClass('d-none')) {
                if($(this).find('input.food_select').is(":checked")){
                    $total = $total + (parseFloat($(this).find('p.price').text()) * parseFloat($(this).find('select.select_quantity').val()));
                }
            };
        });
        $('#Sub_Total').html($total);
        $('#total').html(parseFloat($('#Sub_Total').text()) + parseFloat(parseFloat($('#discount').text())));
        active_checkout_button();
    };

    function check_all_button_selected(){
        if($('input.food_select:checked').length == $('input.food_select').length) {
            $('#select_all').prop('checked', true);
        } else {
            $('#select_all').prop('checked', false);
        }
    }


    // QUANTITY SELECT
    $('select.select_quantity').change(function(){
        $product_price = parseFloat($(this).parent().parent().siblings().find('p.price').text());
        $quantity = parseFloat($(this).val());
        $total_value = $product_price * $quantity;
        $sub_Total = $(this).parent().parent().siblings().find('p.sub-Total').html($total_value + "<span><?php echo CURRENCY; ?></span>");
        count_total_value();
    });


    // SELECT ALL BUTTON
    $('#select_all').change(function() {
        if ($(this).is(":checked")) {
            $(".cart_food").each(function() {
                $(this).find('input.food_select').prop('checked', true);
            });
        } else {
            $(".cart_food").each(function() {
                $(this).find('input.food_select').prop('checked', false);
            });
        }
    });

    // CHECK ALL PRODUCT IS SELECTED OR NOT
    $('input.food_select').change(function(){
        check_all_button_selected();
    });

    // DELET BUTTON
    $('.cart_del').click(function(){
        count_total_value();
        check_all_button_selected();
    });

    // INPUT CHECKBOX
    $('input[type=checkbox]').change(function(){
        count_total_value();
    });

    
    </script>
    <?php } ?>