<div class="text-light d-flex justify-content-center align-items-center login_section">
        <div class="container">
            <form action="#" method="POST">
                <h3>Please enter your details</h3>
                <div class="form-group">
                    <label for="first_name">First Name</label>
                    <input type="text" class="form-control" id="first_name" name="first_name" placeholder="First Name" value="<?php if(isset($_SESSION['user_name'])) {echo $_SESSION['user_name']['first_name'];} ?>" required>
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name" value="<?php if(isset($_SESSION['user_name'])) {echo $_SESSION['user_name']['last_name'];} ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Email" value="<?php if(isset($_SESSION['user_name'])) {echo $_SESSION['user_name']['email'];} ?>" required>
                </div>
                <div class="form-group">
                    <p>You can change your information anytime.</p>
                </div>
                <div class="row justify-content-between align-items-center">
                    <div class="col-auto">
                        <input type="submit" class="btn btn-primary" name="imformation_submit" value="Submit">
                    </div>
                </div>
            </form>
        </div>
    </div>