<div class="owl-carousel text-light d-flex justify-content-center align-items-center login_section" id="login_carousel">
        <div class="item">
            <section class="form_section" id="login" data-hash="login">
                <div class="container">
                    <form method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">
                        <h1>Log In</h1>
                        <div class="w-25 bar"></div>
                        <div class="form-group">
                            <label for="number">Mobile Number</label>
                            <input type="tel" class="form-control" id="number" name="number" placeholder="Mobile Number" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                        </div>
                        <div class="form-check row d-flex justify-content-between align-items-center">
                            <div class="col-auto">
                                <input type="checkbox" class="form-check-input" id="Check">
                                <label class="form-check-label" name="Check" for="Check">Remember me</label>
                            </div>

                            <div class="col-auto">
                                <a class="d-inline-block" href=#>Forgot password? </a>
                            </div>
                        </div>

                        <div class="row justify-content-between align-items-center">
                            <div class="col-auto">
                                <input type="submit" class="btn btn-primary" name="login_submit" value="Login">
                            </div>
                            <div class="col-auto">
                                <a class="d-inline-block" href="#signup">Do not have an account</a>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
        </div>

        <div class="item">
            <section class="form_section" id="signup" data-hash="signup">
                <div class="container">
                    <form method="POST" action="<?php $_SERVER['PHP_SELF']; ?>">
                        <h1>Sign-Up</h1>
                        <div class="w-25 bar"></div>
                        <div class="form-group">
                            <label for="new_number">Mobile Number <span><?php $str_number; ?></span></label>
                            <input type="tel" class="form-control" id="new_number" name="new_number" placeholder="Mobile Number" required>
                        </div>
                        <div class="form-group">
                            <label for="new_password">Password</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Password" required>
                        </div>

                        <div class="form-group">
                            <label for="r_password">Re-enter Password</label>
                            <input type="password" class="form-control" id="r_password" name="r_password" placeholder="Password" required>
                        </div>

                        <div class="row justify-content-between align-items-center">
                            <div class="col-auto">
                                <input type="submit" class="btn btn-primary" name="signup_submit" value="Sign up">
                            </div>
                            <div class="col-auto">
                                <a class="d-inline-block" href="#login">Already have an account</a>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </div>





    <!-- JQUERY -->

    <script>
        $('#login_carousel').owlCarousel({
            loop: false,
            center: true,
            margin: 10,
            nav: false,
            items: 1,
            URLhashListener: true,
            autoplayHoverPause: true,
            startPosition: 'URLHash',
        })
    </script>