<?php
// print_r($viewmodel);
?>
<section class="cart_section">
        <div class="container">
            <div class="upperspacing"></div>
            <div class="row">
                <div class="w-100 my-4 table" id="food_view">
                    <div class="d-none d-md-flex justify-content-between py-2 tr">

                        <div class="w-50 th">
                            <h5>Product</h5>
                        </div>
                        <div class="w-50 th">
                            <div class="row justify-content-around">
                                <h5 class="col-4">Price</h5>
                                <h5 class="col-4">Quantity</h5>
                                <h5 class="col-4">Sub-total</h5>
                            </div>
                        </div>

                    </div>


<!-- product_show -->

<!----------------------------------------------------------------------------------------------- LOOP START -->

                <?php foreach ($viewmodel[0] as $key => $value) { 
                    $str = str_replace("_", " ", ucfirst($value[0]['type']));
                ?>
                <div class="d-flex py-1 tr cart_food">

                        <!-- Name and detail -->
                        <div class="w-50 td">
                            <a class="d-flex" href="<?php echo ROOT_URL; ?>foods/details/<?php echo $value[0]['food_id']?>" target="_blank">
                                <div class="product_img">
                                    <img src="<?php echo ROOT_URL.$value[0]['image_location']; ?>" alt="<?php echo $value[0]['type']; ?>">
                                </div>
                                <div class="product_details px-2">
                                    <p class="food_name">Food name: <span><?php echo $value[0]['food_name'] ?></span></p>
                                    <p class="type">Food type: <?php echo $str ?></p>
                                    <p class="food_id">Food ID: <span><?php echo $value[0]['food_id'] ?></span></p>
                                </div>
                            </a>
                        </div>

                        <div class="w-50 td">
                            <div class="row justify-content-around flex-wrap align-items-center h-100">
                                <!-- Price -->
                                <div class="d-flex justify-content-between justify-content-md-center align-items-center col-12 col-md-4">
                                    <p class="my-0 d-inline-block d-md-none col-6 text-left">Price: </p>
                                    <p class="my-0 col-6 col-md-12 text-right text-md-center price"><?php echo $value[0]['price']; ?> <span><?php echo CURRENCY; ?></span></p>
                                </div>
                                <!-- Quantity -->
                                <div class="d-flex justify-content-between justify-content-md-center align-items-center col-12 col-md-4">
                                    <p class="my-0 d-inline-block d-md-none col-6 text-left">Quantity: </p>
                                    <p class="my-0 col-6 col-md-12 text-right text-md-center"><?php echo $value[1]; ?></p>
                                </div>
                                <!-- Sub-total -->
                                <div class="d-flex justify-content-between justify-content-md-center align-items-center col-12 col-md-4">
                                    <p class="my-0 d-inline-block d-md-none col-6 text-left">Sub-Total: </p>
                                    <p class="my-0 col-6 col-md-12 text-right text-md-center sub-Total price"><?php echo $value[1]*$value[0]['price']; ?> <span><?php echo CURRENCY; ?></span></p>
                                </div>
                            </div>
                        </div>

                </div>
                <?php } ?>

<!----------------------------------------------------------------------------------------------- LOOP END -->      

<!-- TOTAL -->
                <div class="container py-1 total_div">
                    <div class="row justify-content-between">
                        <div class="d-flex align-items-center mr-2">
                            <div class="d-flex justify-content-center flex-column mr-2 px-2">
                                <h6 class="m-0">Order ID: <span><?php echo $viewmodel[1][0]['order_id']; ?></span></h6>

                                <h6 class="m-0">Total: <span id="total"><?php echo $viewmodel[1][0]['total_cost']; ?></span> <?php echo CURRENCY; ?></h6>

                                <p class="m-0">Time: <span id="time"><?php echo $viewmodel[1][0]['DATE_FORMAT(time, "%h:%i %p")']; ?></span></p>
                                <p class="m-0">Date: <span id="date"></span> <?php echo $viewmodel[1][0]['DATE_FORMAT(time, "%d/%m/%Y")']; ?></p>
                                <p class="m-0">Place: <span id="address"></span><?php echo $viewmodel[1][0]['address']; ?></p>
                            </div>

                        </div>

                        <div class="col-md-7 col-12 d-flex align-items-center mx-0 px-0">
                            <?php if ($viewmodel[1][0]['order_status'] != -1) { ?>
                            <div class="progress-track w-100">
                                <ul id="progressbar">
                                    <li class="step0 text-center <?php echo ($viewmodel[1][0]['order_status'] == 0 ? "active" : (($viewmodel[1][0]['order_status'] >= 1) ? "active" : "")) ?>" id="step1">Order Placed</li>
                                    <li class="step0 text-center <?php echo ($viewmodel[1][0]['order_status'] == 0 ? "active" : (($viewmodel[1][0]['order_status'] >= 2) ? "active" : "")) ?>" id="step2">Processing</li>
                                    <li class="step0 text-center <?php echo ($viewmodel[1][0]['order_status'] == 0 ? "active" : (($viewmodel[1][0]['order_status'] >= 3) ? "active" : "")) ?>" id="step3">Delivered</li>
                                    <li class="step0 text-center <?php echo ($viewmodel[1][0]['order_status'] == 0 ? "active" : (($viewmodel[1][0]['order_status'] >= 4) ? "active" : "")) ?>" id="step4">Waiting for payment</li>
                                    <li class="step0 text-center <?php echo (($viewmodel[1][0]['order_status'] == 0) ? "active" : "") ?>" id="step5">Complete</li>
                                </ul>
                            </div>
                            <?php } else { ?>
                            <div class="col-12 d-flex"> 
                                <h1 class="mx-auto my-3 my-md-0">Order Canceled</h1>
                            </div>
                            <?php } ?>
                        </div>

                        <div class="d-flex justify-content-between align-items-center td">
                            <a class="d-flex justify-content-center align-items-center px-2 px-md-4 h-50 py-2 mx-3 mx-md-0 mr-0 mr-md-2 py-md-0 <?php echo $viewmodel[1][0]['order_status'] == 1 ? "active" : "hide" ?>" <?php echo $viewmodel[1][0]['order_status'] != 1 ? "title=\"You can not cancel the order now.\"" : "" ?> id="check_out">Cancel</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
    btn_hover_bubble_effect('#check_out');
</script>